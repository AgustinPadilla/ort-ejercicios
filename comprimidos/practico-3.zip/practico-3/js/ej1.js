let numerosEj1 = '';
for (let i = 1; i <= 1000; i++) {
    numerosEj1 += i + '<br>' 
}

document.querySelector('#pNumerosEj1').innerHTML = numerosEj1;