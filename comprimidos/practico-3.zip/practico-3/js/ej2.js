let numerosEj2 = '';
for (let i = -100; i <= 10; i++) {
    numerosEj2 += i + '<br>' 
}
document.querySelector('#pNumerosEj2').innerHTML = numerosEj2;