let numerosEj3 = '';
for (let i = 40; i >= 10; i--) {
    numerosEj3 += i + '<br>' 
}
document.querySelector('#pNumerosEj3').innerHTML = numerosEj3;