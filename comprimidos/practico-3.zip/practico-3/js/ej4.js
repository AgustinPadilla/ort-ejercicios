let numerosEj4 = '';
for (let i = 20; i >= -30; i--) {
    numerosEj4 += i + '<br>' 
}
document.querySelector('#pNumerosEj4').innerHTML = numerosEj4;