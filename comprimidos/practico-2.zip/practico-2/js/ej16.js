let a = 16;
let b = 1;
let c = 10;

if (a > b || a > c){
    document.querySelector('#parrafoEj16').innerHTML = 'a es el mayor de los 3';
}