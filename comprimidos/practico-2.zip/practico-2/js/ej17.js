let aEj17 = -50;

if (0 > aEj17 || aEj17 > 10){
    document.querySelector('#parrafoEj17').innerHTML = 'a está fuera de rango';
}
console.log(0 > a || a > 10)
